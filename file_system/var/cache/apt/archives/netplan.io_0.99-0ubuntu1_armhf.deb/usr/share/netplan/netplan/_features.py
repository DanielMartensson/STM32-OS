# Generated file
NETPLAN_FEATURE_FLAGS = [
    "generated-supplicant",
    "auth-phase2",
    "dhcp-use-domains",
    "ipv6-mtu",
]
